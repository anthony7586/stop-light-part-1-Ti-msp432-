#include <stdint.h>
#include "SysTick.h"
#include "msp432p401r.h"


void main(void){

}
